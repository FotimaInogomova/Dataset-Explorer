# Dataset Explorer acceptance checks

Run these checks on an extracted copy of the ZIP, not on the owner's working project. Record expected and actual results separately in the matching test receipt beside the ZIP. Use PASS, FAIL, or NOT RUN for each check. A self-test is not peer verification.

1. Extract the ZIP into a new, empty, writable folder. Confirm there is one `Dataset_Explorer/` root. Start the extracted app using the instructions in `README.md`; record the OS, Python version, exact command, URL, and startup result.
2. Upload `samples/M3C6_SAMPLE.csv`. Expected: 3 rows, 3 columns (`record_id`, `category`, `value`), with rows A/red/10, B/blue/20, and C/red/30. If a mean is displayed, it should be 20. Check that the app's other views remain available.
3. Upload the 0-byte `samples/M3C6_EMPTY.csv`. Expected: a clear empty-file message without a traceback.
4. Upload the valid sample again. Expected: the file is read and the 3-row, 3-column summary returns.
5. Stop the extracted app with Ctrl+C. Record packaging, launch, valid CSV, empty CSV, recovery, and peer checks separately. Mark untested OSes and peer review NOT RUN.
