"""Create an isolated environment and launch this portable Streamlit app."""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import venv
import webbrowser

ROOT = Path(__file__).resolve().parent


def choose_port() -> int:
    for port in range(8501, 8511):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise RuntimeError("Ports 8501 through 8510 are busy. Close one of those apps and retry.")


def open_when_ready(url: str, process: subprocess.Popen) -> None:
    for _ in range(120):
        if process.poll() is not None:
            return
        try:
            with urllib.request.urlopen(url + "_stcore/health", timeout=1) as response:
                if response.status == 200:
                    webbrowser.open(url)
                    return
        except (OSError, ValueError):
            pass
        time.sleep(0.5)


def run(no_browser: bool = False) -> int:
    if sys.version_info < (3, 11):
        raise RuntimeError("Python 3.11 or newer is required. Install a compatible Python locally and retry.")

    app = ROOT / "app.py"
    requirements = ROOT / "requirements.txt"
    if not app.is_file() or not requirements.is_file():
        raise RuntimeError("The package is missing app.py or requirements.txt.")

    env = ROOT / ".venv"
    python = env / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not python.is_file():
        print("Creating a local virtual environment...", flush=True)
        venv.create(env, with_pip=True)

    fingerprint = hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker = env / ".requirements.sha256"
    installed = marker.read_text(encoding="ascii").strip() if marker.is_file() else ""
    if installed != fingerprint:
        print("Installing the listed dependencies into .venv; Internet may be needed...", flush=True)
        probe = subprocess.run(
            [str(python), "-m", "pip", "--version"], cwd=ROOT,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if probe.returncode:
            subprocess.run([str(python), "-m", "ensurepip", "--upgrade"], check=True, cwd=ROOT)
        subprocess.run([str(python), "-m", "pip", "install", "-r", str(requirements)], check=True, cwd=ROOT)

    subprocess.run([str(python), "-c", "import streamlit, pandas, numpy, matplotlib"], check=True, cwd=ROOT)
    if installed != fingerprint:
        marker.write_text(fingerprint, encoding="ascii")

    port = choose_port()
    url = f"http://127.0.0.1:{port}/"
    command = [
        str(python), "-m", "streamlit", "run", str(app),
        "--server.address", "127.0.0.1", "--server.port", str(port),
        "--server.headless", "true", "--browser.gatherUsageStats", "false",
    ]
    print(f"Local URL: {url}\nPress Ctrl+C to stop.", flush=True)
    process = subprocess.Popen(command, cwd=ROOT)
    if not no_browser:
        threading.Thread(target=open_when_ready, args=(url, process), daemon=True).start()

    try:
        return process.wait()
    except KeyboardInterrupt:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        return 130


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true", help="Do not open a browser automatically")
    args = parser.parse_args()
    try:
        return run(args.no_browser)
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print(f"Launch failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
