#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
    python3 launcher.py "$@"
elif command -v python >/dev/null 2>&1; then
    python launcher.py "$@"
else
    echo "Python 3.11 or newer is required. See README.md."
    exit 1
fi
result=$?
if [ "$result" -ne 0 ]; then
    echo "Launch failed. See the message above and README.md."
    if [ -t 0 ]; then read -r -p "Press Enter to close..."; fi
fi
exit "$result"
