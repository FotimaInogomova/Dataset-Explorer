@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3.12 --version >nul 2>nul
if not errorlevel 1 goto use_tested
py -3 launcher.py %*
goto report
:use_tested
py -3.12 launcher.py %*
goto report
:use_python
python launcher.py %*
:report
set "result=%errorlevel%"
if not "%result%"=="0" (
    echo Launch failed. See the message above and README.md.
    pause
)
exit /b %result%
