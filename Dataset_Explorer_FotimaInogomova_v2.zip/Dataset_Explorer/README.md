# Dataset Explorer — handoff package

This is a portable **source package**, not an installer or executable. It contains the Dataset Explorer app, launch helpers, and two small CSV acceptance samples. Your original project folder is not part of this archive.

## What is included

- `app.py` and `.streamlit/config.toml`
- `requirements.txt` with the app's direct dependencies pinned to versions verified in the owner's environment
- `launcher.py` and start files for Windows, macOS, and Linux
- `samples/M3C6_SAMPLE.csv` and a zero-byte `samples/M3C6_EMPTY.csv`
- `TESTS.md` with acceptance checks

## Requirements

Install a compatible Python 3.11 or newer with `venv` and `pip`. This package was verified on Windows 11 with Python 3.12.6. The listed package versions have not been verified on macOS, Linux, or other Python versions. The first launch installs packages from `requirements.txt` and may need Internet access. The launcher creates `.venv` in this extracted folder and does not modify the system Python or request administrator access.

## Start

- **Windows:** double-click `START_WINDOWS.cmd`, or run `py -3.12 launcher.py` in PowerShell from this folder. The start file prefers the tested Python 3.12 and falls back to the default `py -3` only if 3.12 is unavailable. If that Python version cannot create a working venv or install packages, use a compatible Python and ask for help with the exact error.
- **macOS:** run `bash START_MAC.command` in Terminal.
- **Linux:** run `bash START_LINUX.sh` in a terminal.

Keep the terminal open while using the app. Open the `Local URL` printed there (usually `http://127.0.0.1:8501/`). If that port is busy, the launcher checks ports 8502 through 8510. Stop the app with Ctrl+C.

## Data handling

The app reads uploaded CSV files locally. It does not edit or clean the uploaded source data. See the app for supported views and details on missing values, duplicate rows, whitespace-only values, numeric inspection, and comparison.

## Verification status

The release receipt beside the ZIP records the actual fresh-extraction checks and clearly marks untested operating systems and peer review. Do not infer cross-platform support from the presence of launcher files.
